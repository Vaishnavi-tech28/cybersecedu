
const connectorConfig = {
  connector: 'default',
  service: 'cybersecedu-main',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
